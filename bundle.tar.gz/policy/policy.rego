package trino

import rego.v1

default allow := false

verified_claims := claims if {
    token := input.context.identity.extraCredentials.jwt
    secret_base64 := opa.runtime().env.JWT_SECRET_BASE64
    secret := base64.decode(secret_base64)
    decoded := io.jwt.decode_verify(token, {
        "alg": "HS256",
        "iss": "opa-permission",
        "secret": secret,
    })
    decoded[0] == true
    claims := decoded[2]
}

authenticated if {
    identity := input.context.identity
    verified_claims.sub == identity.user
}

allow if {
    authenticated

    table := input.action.resource.table
    table.catalogName == "local_pg"
    table.schemaName == "public"
    table.tableName == "customers"
    table.columns == ["customer_name"]
}

allow if {
    authenticated
    input.action.operation == "ExecuteQuery"
}

columnMask := {"expression": "concat('**', substr(customer_name, 3))"} if {
    authenticated
    verified_claims.clearance == 3

    column := input.action.resource.column
    column.catalogName == "local_pg"
    column.schemaName == "public"
    column.tableName == "customers"
    column.columnName == "customer_name"
}